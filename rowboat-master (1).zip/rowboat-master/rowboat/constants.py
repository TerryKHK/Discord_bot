import re
import yaml
from disco.types.user import GameType, Status

with open('config.yaml', 'r') as f:
    data = yaml.load(f)

# Emojis
GREEN_TICK_EMOJI_ID = 326794577006690305
RED_TICK_EMOJI_ID = 326794577426251796
ONLINE_EMOJI_ID = 341642512269574145
IDLE_EMOJI_ID = 341642512475095050
DND_EMOJI_ID = 341642512127229953
OFFLINE_EMOJI_ID = 341642512576020480
STREAMING_EMOJI_ID = 341644191362711552
STAR_EMOJI = u'\U00002B50'
SNOOZE_EMOJI = u'\U0001f4a4'

# IDs and such
ROWBOAT_GUILD_ID = 146691885363232769
ROWBOAT_USER_ROLE_ID = 461886806640558080
ROWBOAT_CONTROL_CHANNEL = 297917022300274688

# Bot info
ROWBOAT_NAME = 'Rowboat'
ROWBOAT_INFO = 'is a moderation and utilitarian bot built for large Discord servers.'

# Regexes
INVITE_LINK_RE = re.compile(r'(discordapp.com/invite|discord.me|discord.gg)(?:/#)?(?:/invite)?/([a-z0-9\-]+)', re.I)
URL_RE = re.compile(r'(https?://[^\s]+)')
EMOJI_RE = re.compile(r'<a?:(.+):([0-9]+)>')
RAW_EMOJI_RE = re.compile('^[0-9]{18}$')
USER_MENTION_RE = re.compile('<@!?([0-9]+)>')

# Discord Error codes
ERR_UNKNOWN_MESSAGE = 10008

# Etc
YEAR_IN_SEC = 60 * 60 * 24 * 365
CDN_URL = 'https://twemoji.maxcdn.com/2/72x72/{}.png'

# Loaded from files
with open('data/badwords.txt', 'r') as f:
    BAD_WORDS = f.readlines()

DOMAIN = data['web']['DOMAIN']

# Merge in any overrides in the config
with open('config.yaml', 'r') as f:
    loaded = yaml.load(f.read())
    locals().update(loaded.get('constants', {}))

STATUS_EMOJI = {
    Status.ONLINE: ':status_online:{}'.format(ONLINE_EMOJI_ID),
    Status.IDLE: ':status_away:{}'.format(IDLE_EMOJI_ID),
    Status.DND: ':status_dnd:{}'.format(DND_EMOJI_ID),
    Status.OFFLINE: ':status_offline:{}'.format(OFFLINE_EMOJI_ID),
    GameType.STREAMING: ':status_streaming:{}'.format(STREAMING_EMOJI_ID),
}

GREEN_TICK_EMOJI = 'green_tick:{}'.format(GREEN_TICK_EMOJI_ID)
RED_TICK_EMOJI = 'red_tick:{}'.format(RED_TICK_EMOJI_ID)
