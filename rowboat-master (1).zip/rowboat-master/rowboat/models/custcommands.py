from peewee import (
    BigIntegerField, TextField, DateTimeField, CompositeKey, IntegerField
)
from datetime import datetime
from holster.enum import Enum

from rowboat.sql import BaseModel


@BaseModel.register
class CustomCommands(BaseModel):
    Types = Enum(
        'CMD',
        'LISTEN',
        bitmask=False,
    )

    ListenTypes = Enum(
        'GuildMemberAdd',
        'GuildMemberRemove',
        'GuildMemberUpdate',
        'GuildMembersChunk',
        'GuildRoleCreate',
        'GuildRoleUpdate',
        'GuildRoleDelete',
        'GuildEmojisUpdate',
        'ChannelCreate',
        'ChannelUpdate',
        'ChannelDelete',
        'VoiceStateUpdate',
        'MessageCreate',
        'PresenceUpdate',
        bitmask=False,
    )

    guild_id = BigIntegerField()
    author_id = BigIntegerField()

    type_ = IntegerField(db_column='type')
    listen_type_ = IntegerField(db_column='listen_type',default=0)

    name = TextField()
    command = TextField()
    times_used = IntegerField(default=0)

    created_at = DateTimeField(default=datetime.utcnow)

    class Meta:
        db_table = 'custom_commands'
        primary_key = CompositeKey('guild_id', 'name')

    @classmethod
    def create_cust(cls, plugin, event, name, cmdtype, ltype, content):
        cls.create(
            guild_id=event.guild.id,
            author_id=event.author.id,
            name=name,
            command=content,
            type_=cmdtype,
            listen_type_=ltype
        )
