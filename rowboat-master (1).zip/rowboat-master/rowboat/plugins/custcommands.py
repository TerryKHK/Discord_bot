# -*- coding: utf-8 -*-
import os
import re
import csv
import gevent
import humanize
import pytz

from StringIO import StringIO
from holster.emitter import Priority
from fuzzywuzzy import fuzz

from datetime import datetime

from disco.bot import CommandLevels
from disco.types.user import User as DiscoUser
from disco.types.base import cached_property
from disco.types.channel import MessageIterator, ChannelType
from disco.types.message import MessageTable, MessageEmbed
from disco.util.sanitize import S
from disco.util.snowflake import to_snowflake

from rowboat.plugins import RowboatPlugin as Plugin, CommandFail, CommandSuccess
from rowboat.util.timing import Eventual
from rowboat.util.input import parse_duration, parse_duration_seconds
from rowboat.types import SlottedModel, DictField, ListField, Field, snowflake
from rowboat.types.plugin import PluginConfig
from rowboat.plugins.modlog import Actions
from rowboat.models.user import User, Infraction
from rowboat.models.custcommands import CustomCommands
from rowboat.models.message import Message

from rowboat.sql import database
from rowboat.constants import (
    GREEN_TICK_EMOJI_ID, RED_TICK_EMOJI_ID, GREEN_TICK_EMOJI, RED_TICK_EMOJI
)

def clamp(string, size):
    if len(string) > size:
        return string[:size] + '...'
    return string

class Object():
    pass

class CustCommandsConfig(PluginConfig):
    enabled = Field(bool, default=True)

@Plugin.with_config(CustCommandsConfig)
class CustCommandsPlugin(Plugin):
    def load(self, ctx):
        super(CustCommandsPlugin, self).load(ctx)

    @Plugin.listen('GuildMemberAdd')
    def cust_cmd_guild_member_add(self, event):
        pass

    @Plugin.listen('GuildMemberRemove')
    def cust_cmd_guild_member_remove(self, event):
        pass

    @Plugin.listen('GuildMemberUpdate')
    def cust_cmd_guild_member_update(self, event):
        pass

    @Plugin.listen('GuildMembersChunk')
    def cust_cmd_guild_member_chunk(self, event):
        pass

    @Plugin.listen('GuildRoleCreate')
    def cust_cmd_guild_role_create(self, event):
        pass

    @Plugin.listen('GuildRoleUpdate')
    def cust_cmd_guild_role_update(self, event):
        pass

    @Plugin.listen('GuildEmojisUpdate')
    def cust_cmd_guild_emojis_update(self, event):
        pass

    @Plugin.listen('ChannelCreate')
    def cust_cmd_channel_create(self, event):
        pass

    @Plugin.listen('ChannelDelete')
    def cust_cmd_channel_delete(self, event):
        pass

    @Plugin.listen('VoiceStateUpdate')
    def cust_cmd_voice_state_update(self, event):
        pass

    @Plugin.listen('MessageCreate')
    def cust_cmd_message_create(self, event):
        # Ignore messages sent by bots
        if event.message.author.bot:
            return

        try:
            custcmds = CustomCommands.select().where(
                (CustomCommands.guild_id == event.guild.id) &
                (CustomCommands.type_ == CustomCommands.Types.LISTEN) &
                (CustomCommands.listen_type_ == CustomCommands.ListenTypes.MessageCreate)
            )
        except:
            custcmds = None

        if custcmds is None:
            return

        # Loop through all the defined commands and execute
        for cmd in custcmds:
            cmds = cmd.command.split("|")
            member = event.guild.get_member(event.author.id)
            for c in cmds:
                c = c.lstrip()
                if c.lower().startswith('reactall'):
                    channel = c.split()[1]
                    emoji_id = c.split()[2]
                    if channel is None or emoji_id is None:
                        return
                    if event.channel.id == int(channel):
                        event.add_reaction(emoji_id)

                if c.lower().startswith('replyall'):
                    channel = c.split()[1]
                    msg = c.split(' ', 2)[2]
                    if channel is None or msg is None:
                        return
                    if event.channel.id == int(channel):
                        event.reply(msg)

                if c.lower().startswith('react'):
                    searchstr = c.split()[1]
                    emoji_id = c.split()[2]
                    if searchstr is None or emoji_id is None:
                        return
                    if searchstr.lower() in event.message.content.lower():
                        event.add_reaction(msg)

                if c.lower().startswith('reply'):
                    searchstr = c.split()[1]
                    msg = c.split(' ', 2)[2]
                    if searchstr is None or msg is None:
                        return
                    if searchstr.lower() in event.message.content.lower():
                        event.reply(msg)

    @Plugin.listen('PresenceUpdate')
    def cust_cmd_presence_update(self, event):
        pass

    @Plugin.command('create', '<name:str> <cmdtype:str> <ltype:str> <content:str...>', group='cc', level=CommandLevels.ADMIN)
    def cust_cmd_create(self, event, name, cmdtype, ltype, content):
        if not cmdtype.lower() in CustomCommands.Types.keys_:
            raise CommandFail(u'{} is not a valid type option'.format(cmdtype))

        if not ltype.lower() in CustomCommands.ListenTypes.keys_:
            if not cmdtype.lower() == 'cmd':
                raise CommandFail(u'{} is not a valid listen type'.format(ltype))

        if cmdtype.upper() == CustomCommands.Types.CMD:
            CustomCommands.create_cust(self, event, name, CustomCommands.Types.CMD, int(0), content)
            raise CommandSuccess(u'ok, created command `{}`'.format(name))

        if cmdtype.upper() == CustomCommands.Types.LISTEN:
            if ltype == CustomCommands.ListenTypes.MessageCreate:
                CustomCommands.create_cust(self, event, name, CustomCommands.Types.LISTEN, CustomCommands.ListenTypes.MessageCreate, content)
                raise CommandSuccess(u'ok, created command `{}`'.format(name))
            else:
                raise CommandFail(u'Unfortunately that LISTEN option is not implemented at this moment')

    @Plugin.command('remove', '<name:str>', group='cc', aliases=['del','rm'], level=CommandLevels.ADMIN)
    def cust_cmd_remove(self, event, name):
        try:
            cmd = CustomCommands.select(CustomCommands, User).join(
                User, on=(User.user_id == CustomCommands.author_id).alias('author')
            ).where(
                 (CustomCommands.guild_id == event.guild.id) &
                 (CustomCommands.name == name)
            ).get()
        except CustomCommands.DoesNotExist:
            raise CommandFail('cannot find a custom command with Name `{}`'.format(name))

        cmd.delete_instance()
        raise CommandSuccess(u'ok, deleted command `{}`'.format(cmd.name))

    @Plugin.command('info', '<name:str>', group='cc', level=CommandLevels.ADMIN)
    def cust_cmd_info(self, event, name):
        try:
            cmd = CustomCommands.select(CustomCommands, User).join(
                User, on=(User.user_id == CustomCommands.author_id).alias('author')
            ).where(
                 (CustomCommands.guild_id == event.guild.id) &
                 (CustomCommands.name == name)
            ).get()
        except CustomCommands.DoesNotExist:
            raise CommandFail('cannot find a custom command with Name `{}`'.format(name))

        type_ = {i.index: i for i in CustomCommands.Types.attrs}[cmd.type_]
        if type_ == 'CMD':
            listen_type_ = 'N/A'
        else:
            listen_type_ = {i.index: i for i in CustomCommands.ListenTypes.attrs}[cmd.listen_type_]

        embed = MessageEmbed()

        embed.color = 0xff6961
        embed.title = str(type_).title()
        embed.add_field(name='Type', value=unicode(str(type_).title()), inline=True)
        embed.add_field(name='ListenType', value=unicode(str(listen_type_).title()), inline=True)
        embed.add_field(name='Used', value=cmd.times_used, inline=True)
        embed.add_field(name='Type', value=unicode(cmd.author), inline=True)

        cmds = cmd.command.split("|")
        c = 0
        for command in cmds:
            c += 1
            command = command.lstrip()
            embed.add_field(name='Command # {}'.format(c), value=unicode(command), inline=False)

        embed.timestamp = cmd.created_at.isoformat()
        event.msg.reply('', embed=embed)

    @Plugin.command('all', group='cc', level=CommandLevels.ADMIN)
    def cust_cmd_show_all(self, event):
        try:
            cmds = CustomCommands.select(CustomCommands, User).join(
                User, on=(User.user_id == CustomCommands.author_id).alias('author')
            ).where(
                 (CustomCommands.guild_id == event.guild.id)
            )
        except:
            raise CommandFail('An error occured. The error was error.')

        tbl = MessageTable()

        tbl.set_header('Name', 'Author', 'Created', 'Used', 'Type', 'Listen Type', 'Commands')

        for cmd in cmds:
            if len(clamp(cmd.command, 128)) + len(tbl.compile()) > 1800:
                event.msg.reply(tbl.compile())
                tbl = MessageTable()
                tbl.set_header('Name', 'Author', 'Created', 'Used', 'Type', 'Listen Type', 'Commands')

            type_ = {i.index: i for i in CustomCommands.Types.attrs}[cmd.type_]
            if type_ == 'CMD':
                listen_type_ = 'N/A'
            else:
                listen_type_ = {i.index: i for i in CustomCommands.ListenTypes.attrs}[cmd.listen_type_]

            tbl.add(
                cmd.name,
                cmd.author,
                cmd.created_at.strftime("%d-%b-%y @ %H:%M"),
                cmd.times_used,
                str(type_),
                str(listen_type_),
                clamp(cmd.command, 128)
            )

        event.msg.reply(tbl.compile())

    def cust_cmd_run(self, event, config, guild, name, command):
        notify = False
        allowargs = False
        reason = None

        emoji = 'white_check_mark'

        cmds = command.split("|")
        member = event.guild.get_member(event.author.id)

        for cmd in cmds:
            cmd = cmd.lstrip()
            if allowargs:
                user_id = event.message.content.split()[1]
                try:
                    reason = event.message.content.split(' ', 2)[2]
                except IndexError:
                    reason = None

                u = Object()

                if user_id.isnumeric():
                    u.id = user_id
                    member = event.guild.get_member(u)
                else:
                    user = re.sub('[^0-9]','', user_id)
                    u.id = user
                    member = event.guild.get_member(u)

                if member is None:
                    u.id = user_id
                    member = Object()
                    member = int(to_snowflake(u))

            if cmd.lower().split()[0] == 'allowargs':
                allowargs = True

            if cmd.lower().split()[0] == 'notify':
                notify = True

            if cmd.lower().split()[0] == 'addgroup':
                role = None
                role = self.cust_cmd_getrole(config, guild, cmd.split()[1])
                if role is None:
                    return
                member.add_role(role)
                if notify:
                    event.message.reply(u':{}: added +{}'.format(emoji, role))

            if cmd.lower().split()[0] == 'removegroup':
                role = None
                role = self.cust_cmd_getrole(config, guild, cmd.split()[1])
                if role is None:
                    return
                member.remove_role(role)
                if notify:
                    event.message.reply(u':{}: removed -{}'.format(emoji, role))

            if cmd.lower().split()[0] == 'addgrouptemp':
                role = None
                role = self.cust_cmd_getrole(config, guild, cmd.split()[1])
                dur = cmd.split()[2]
                if role is None:
                    return
                expire_dt = parse_duration(dur)
                if reason is None:
                    reason = cmd.split(' ', 3)[3]
                if reason is None:
                    reason = 'CUSTCMD'
                Infraction.temprole(self, event, member, role.id, reason, expire_dt)
                self.call('InfractionsPlugin.queue_infractions')
                if notify:
                    event.message.reply(u':{}: added temp +{}'.format(emoji, role))

            if cmd.lower().split()[0] == 'kick':
                if reason is None:
                    reason = cmd.split(' ', 1)[1]
                if reason is None:
                    reason = 'CUSTCMD'
                Infraction.kick(self, event, member, reason)
                if notify:
                    event.message.reply(u':{}: kicked {}'.format(emoji, member.name))

            if cmd.lower().split()[0] == 'tempban':
                dur = cmd.split()[1]
                expire_dt = parse_duration(dur)
                if reason is None:
                    reason = cmd.split(' ', 2)[2]
                if reason is None:
                    reason = 'CUSTCMD'
                Infraction.tempban(self, event, member, reason, expire_dt)
                self.call('InfractionsPlugin.queue_infractions')
                if notify:
                    event.message.reply(u':{}: temp banned {}'.format(emoji, member.name))

            if cmd.lower().split()[0] == 'softban':
                if reason is None:
                    reason = cmd.split(' ', 1)[1]
                if reason is None:
                    reason = 'CUSTCMD'
                Infraction.softban(self, event, member, reason)
                if notify:
                    event.message.reply(u':{}: soft banned {}'.format(emoji, member.name))

            if cmd.lower().split()[0] == 'ban':
                if reason is None:
                    reason = cmd.split(' ', 1)[1]
                if reason is None:
                    reason = 'CUSTCMD'
                Infraction.ban(self, event, member, reason, guild)
                if notify:
                    event.message.reply(u':{}: banned {}'.format(emoji, member.name))

            if cmd.lower().split()[0] == 'warn':
                if reason is None:
                    reason = cmd.split(' ', 1)[1]
                if reason is None:
                    reason = 'CUSTCMD'
                Infraction.warn(self, event, member, reason, guild)
                if notify:
                    event.message.reply(u':{}: warned {}'.format(emoji, member.name))

            if cmd.lower().split()[0] == 'mute':
                if reason is None:
                    reason = cmd.split(' ', 1)[1]
                if reason is None:
                    reason = 'CUSTCMD'
                Infraction.mute(self, event, member, reason)
                if notify:
                    event.message.reply(u':{}: muted {}'.format(emoji, member.name))

            if cmd.lower().split()[0] == 'mutehard':
                if reason is None:
                    reason = cmd.split(' ', 1)[1]
                if reason is None:
                    reason = 'CUSTCMD'
                Infraction.mutehard(self, event, member, reason)
                if notify:
                    event.message.reply(u':{}: hard muted {}'.format(emoji, member.name))

            if cmd.lower().split()[0] == 'tempmute':
                dur = cmd.split()[1]
                expire_dt = parse_duration(dur)
                if reason is None:
                    reason = cmd.split(' ', 2)[2]
                if reason is None:
                    reason = 'CUSTCMD'
                Infraction.tempmute(self, event, member, reason, expire_dt)
                self.call('InfractionsPlugin.queue_infractions')
                if notify:
                    event.message.reply(u':{}: temp muted {}'.format(emoji, member.name))

            if cmd.lower().split()[0] == 'tempmutehard':
                dur = cmd.split()[1]
                expire_dt = parse_duration(dur)
                if reason is None:
                    reason = cmd.split(' ', 2)[2]
                if reason is None:
                    reason = 'CUSTCMD'
                Infraction.tempmutehard(self, event, member, reason, expire_dt)
                self.call('InfractionsPlugin.queue_infractions')
                if notify:
                    event.message.reply(u':{}: temp hard muted {}'.format(emoji, member.name))

            if cmd.lower().split()[0] == 'mutevc':
                Infraction.move_vc(self, event, member)
                if notify:
                    event.message.reply(u':{}: muted voice for {}'.format(emoji, member.name))

        # Track the usage of the command
        CustomCommands.update(times_used=CustomCommands.times_used + 1).where(
            (CustomCommands.guild_id == event.guild.id) &
            (CustomCommands.name == name)
        ).execute()

    def cust_cmd_getrole(self, config, guild, role):
        role_obj = None

        if role.isdigit() and int(role) in guild.roles.keys():
            role_obj = guild.roles[int(role)]
        else:
            # First try exact match
            exact_matches = [i for i in guild.roles.values() if i.name.lower().replace(' ', '') == role.lower()]
            if len(exact_matches) == 1:
                role_obj = exact_matches[0]
            else:
                # Otherwise we fuzz it up
                rated = sorted([
                    (fuzz.partial_ratio(role, r.name.replace(' ', '')), r) for r in guild.roles.values()
                ], key=lambda i: i[0], reverse=True)

                if rated[0][0] > 40:
                    if len(rated) == 1:
                        role_obj = rated[0][1]
                    elif rated[0][0] - rated[1][0] > 20:
                        role_obj = rated[0][1]

        if not role_obj:
            raise CommandFail('too many matches for that role, try something more exact or the role ID')

        return role_obj
