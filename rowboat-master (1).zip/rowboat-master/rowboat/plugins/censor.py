import re
import json
import urlparse
import random
import time

from datetime import datetime, timedelta
from holster.enum import Enum
from holster.emitter import Priority
from disco.types.base import UNSET, cached_property
from disco.util.sanitize import S
from disco.api.http import APIException

from rowboat.redis import rdb
from rowboat.util.stats import timed
from rowboat.util.leakybucket import LeakyBucket
from rowboat.util.zalgo import ZALGO_RE
from rowboat.plugins import RowboatPlugin as Plugin
from rowboat.types import SlottedModel, Field, ListField, DictField, ChannelField, snowflake, lower
from rowboat.types.plugin import PluginConfig
from rowboat.models.message import Message
from rowboat.models.user import Infraction
from rowboat.plugins.modlog import Actions
from rowboat.constants import INVITE_LINK_RE, URL_RE

CensorReason = Enum(
    'INVITE',
    'DOMAIN',
    'WORD',
    'ZALGO',
    'LENGTH'
)



class CensorSubConfig(SlottedModel):
    filter_zalgo = Field(bool, default=True)
    zalgo_channel_whitelist = ListField(snowflake)

    filter_invites = Field(bool, default=True)
    invites_guild_whitelist = ListField(snowflake, default=[])
    invites_whitelist = ListField(lower, default=[])
    invites_blacklist = ListField(lower, default=[])
    invites_channel_whitelist = ListField(snowflake)

    filter_domains = Field(bool, default=True)
    domains_whitelist = ListField(lower, default=[])
    domains_blacklist = ListField(lower, default=[])
    domains_channel_whitelist = ListField(snowflake)

    blocked_words = ListField(lower, default=[])
    blocked_tokens = ListField(lower, default=[])
    words_channel_whitelist = ListField(snowflake)

    blocked_nicknames = ListField(lower, default=[])
    block_zalgo_nicknames = Field(bool, default=False)

    message_char_limit = Field(int, default=0)
    char_limit_channel_whitelist = ListField(snowflake)
    warn_on_censor = Field(bool, default=False)

    mute_violations = Field(bool, default=False)
    mute_violations_interval = Field(int, default=10)
    mute_violations_count = Field(int, default=3)
    mute_violations_duration = Field(int, default=300)

    _cached_max_invite_bucket = Field(str, private=True)
    _cached_max_domain_bucket = Field(str, private=True)
    _cached_max_word_bucket = Field(str, private=True)
    _cached_max_zalgo_bucket = Field(str, private=True)
    _cached_max_length_bucket = Field(str, private=True)

    @cached_property
    def blocked_re(self):
        return re.compile(u'({})'.format(u'|'.join(
            map(re.escape, self.blocked_tokens) +
            map(lambda k: u'\\b{}\\b'.format(re.escape(k)), self.blocked_words)
        )), re.I)

    @cached_property
    def blockednick_re(self):
        return re.compile('{}'.format('|'.join(
            map(lambda k: '{}'.format(re.escape(k)), self.blocked_nicknames)
        )), re.I)

    def get_bucket(self, attr, guild_id):
        if not self.mute_violations:
            return (None)

        bucket = getattr(self, '_cached_{}_bucket'.format(attr), None)
        if not bucket:
            bucket = LeakyBucket(rdb, 'censor:{}:{}:{}'.format(attr, guild_id, '{}'), self.mute_violations_count, self.mute_violations_interval * 1000)
            setattr(self, '_cached_{}_bucket'.format(attr), bucket)

        return bucket

class CensorConfig(PluginConfig):
    levels = DictField(int, CensorSubConfig)
    channels = DictField(ChannelField, CensorSubConfig)

    def compute_relevant_rules(self, event, level):
        if self.channels:
            for chn in self.channels.keys():
                if chn == event.channel.id:
                    yield self.channels[chn]

        if self.levels:
            for lvl in self.levels.keys():
                if level <= lvl:
                    yield self.levels[lvl]

# It's bad kids!
class Censorship(Exception):
    def __init__(self, reason, event, ctx):
        self.reason = reason
        self.event = event
        self.ctx = ctx
        self.content = S(event.content, escape_codeblocks=True)

    @property
    def details(self):
        msg = ''
        if self.reason is CensorReason.INVITE:
            if self.ctx['guild']:
                msg = u'invite `{}` to {}'.format(
                    self.ctx['invite'],
                    S(self.ctx['guild']['name'], escape_codeblocks=True)
                )
            else:
                msg = u'invite `{}`'.format(self.ctx['invite'])
        elif self.reason is CensorReason.DOMAIN:
            if self.ctx['hit'] == 'whitelist':
                msg = u'domain `{}` is not in whitelist'.format(S(self.ctx['domain'], escape_codeblocks=True))
            else:
                msg = u'domain `{}` is in blacklist'.format(S(self.ctx['domain'], escape_codeblocks=True))
        elif self.reason is CensorReason.WORD:
            msg = u'found blacklisted words `{}`'.format(
                u', '.join([S(i, escape_codeblocks=True) for i in self.ctx['words']]))
        elif self.reason is CensorReason.ZALGO:
            msg = u'found zalgo at position `{}` in text'.format(
                self.ctx['position']
            )
        elif self.reason is CensorReason.LENGTH:
            msg = u'message was {} characters, {} allowed'.format(self.ctx['length'], self.ctx['allowed'])

        if self.ctx['warn_on_censor'] and not rdb.exists('censorid:{}'.format(self.event.id)):
            # Store the event ID to get around weird race condition that seems to occur in busy guilds
            rdb.setex('censorid:{}'.format(self.event.id), self.event.member.id, 15)
            Infraction.warn(self.ctx['s'], self.event, self.event.member, 'Censor: {}'.format(msg), guild=self.event.member.guild)

        return msg

class Violation(Exception):
    def __init__(self, rule, event, member, label, msg, **info):
        self.rule = rule
        self.event = event
        self.member = member
        self.label = label
        self.msg = msg
        self.info = info

@Plugin.with_config(CensorConfig)
class CensorPlugin(Plugin):
    global idlist
    idlist = []

    def compute_relevant_configs(self, event, author):
        if hasattr(event, 'channel_id'):
            if event.channel_id in event.config.channels:
                yield event.config.channels[event.channel.id]

        if event.config.levels:
            user_level = int(self.bot.plugins.get('CorePlugin').get_level(event.guild, author))

            for level, config in event.config.levels.items():
                if user_level <= level:
                    yield config

    def violate(self, violation):
        key = 'cv:{e.member.guild_id}:{e.member.id}'.format(e=violation.event)
        last_violated = int(rdb.get(key) or 0)
        rdb.setex('cv:{e.member.guild_id}:{e.member.id}'.format(e=violation.event), int(time.time()), 60)

        if not last_violated > time.time() - 10:
            self.call(
                'ModLogPlugin.log_action_ext',
                Actions.CENSOR_DEBUG,
                violation.event.guild.id,
                v=violation
            )

            punishment_duration = violation.rule.mute_violations_duration or violation.check.mute_violations_duration

            Infraction.tempmute(
                self,
                violation.event,
                violation.member,
                'To many censor violations',
                datetime.utcnow() + timedelta(seconds=punishment_duration))

    def get_invite_info(self, code):
        if rdb.exists('inv:{}'.format(code)):
            return json.loads(rdb.get('inv:{}'.format(code)))

        try:
            obj = self.client.api.invites_get(code)
        except:
            return

        obj = {
            'id': obj.guild.id,
            'name': obj.guild.name,
            'icon': obj.guild.icon
        }

        # Cache for 12 hours
        rdb.setex('inv:{}'.format(code), json.dumps(obj), 43200)
        return obj

    @Plugin.listen('MessageUpdate')
    def on_message_update(self, event):
        try:
            msg = Message.get(id=event.id)
        except Message.DoesNotExist:
            self.log.info('Not censoring MessageUpdate for id %s, %s, no stored message', event.channel_id, event.id)
            return

        if not event.content:
            return

        return self.on_message_create(
            event,
            author=event.guild.get_member(msg.author_id))

    @Plugin.listen('MessageCreate')
    def on_message_create(self, event, author=None):
        author = author or event.author

        if author.id == self.state.me.id:
            return

        if event.webhook_id:
            return

        configs = list(self.compute_relevant_configs(event, author))
        if not configs:
            return

        tags = {'guild_id': event.guild.id, 'channel_id': event.channel.id}
        with timed('rowboat.plugin.censor.duration', tags=tags):
            try:
                # TODO: perhaps imap here? how to raise exception then?
                for config in configs:
                    if config.filter_zalgo:
                        if event.channel.id in config.zalgo_channel_whitelist:
                            return
                        self.filter_zalgo(event, config)

                    if config.filter_invites:
                        if event.channel.id in config.invites_channel_whitelist:
                            return
                        self.filter_invites(event, config)

                    if config.filter_domains:
                        if event.channel.id in config.domains_channel_whitelist:
                            return
                        self.filter_domains(event, config)

                    if config.blocked_words or config.blocked_tokens:
                        if event.channel.id in config.words_channel_whitelist:
                            return
                        self.filter_blocked_words(event, config)

                    if config.message_char_limit:
                        if event.channel.id in config.char_limit_channel_whitelist:
                            return
                        self.filter_message_len(event, config)

            except Censorship as c:
                self.call(
                    'ModLogPlugin.create_debounce',
                    event,
                    ['MessageDelete'],
                    message_id=event.message.id,
                )

                try:
                    if 'invite' in c.details:
                        censor_type = 'max_invite'
                    elif 'domain' in c.details:
                        censor_type = 'max_domain'
                    elif 'word' in c.details:
                        censor_type = 'max_word'
                    elif 'zalgo' in c.details:
                        censor_type = 'max_zalgo'
                    elif 'length' in c.details:
                        censor_type = 'max_length'
                    else:
                        censor_type = None

                    event.delete()

                    self.call(
                        'ModLogPlugin.log_action_ext',
                        Actions.CENSORED,
                        event.guild.id,
                        e=event,
                        c=c)

                    if censor_type:
                        level = int(self.bot.plugins.get('CorePlugin').get_level(event.guild, event.author))
                        member = event.guild.get_member(event.author)
                        for rule in event.config.compute_relevant_rules(event, level):
                            self.check_message_simple(event, member, rule, censor_type)

                except Violation as v:
                    self.violate(v)
                except APIException:
                    self.log.exception('Failed to delete censored message: {}'.format(event.id))

    def check_message_simple(self, event, member, rule, censor_type):
        def check_bucket(name, base_text, func):
            bucket = rule.get_bucket(name, event.guild.id)
            if not bucket:
                return

            if not bucket.check(event.author.id, func(event) if callable(func) else func):
                raise Violation(rule, event, member,
                    name.upper(),
                    base_text + ' ({} / {}s)'.format(bucket.count(event.author.id), bucket.size(event.author.id)))

        check_bucket(censor_type, 'To many censor violations', 1)

    def filter_zalgo(self, event, config):
        s = ZALGO_RE.search(event.content)
        if s:
            raise Censorship(CensorReason.ZALGO, event, ctx={
                'position': s.start(),
                'warn_on_censor': config.warn_on_censor,
                's': self,
            })

    def filter_invites(self, event, config):
        invites = INVITE_LINK_RE.findall(event.content)

        for _, invite in invites:
            invite_info = self.get_invite_info(invite)

            need_whitelist = (
                config.invites_guild_whitelist or
                (config.invites_whitelist or not config.invites_blacklist)
            )
            whitelisted = False

            if invite_info and invite_info.get('id') in config.invites_guild_whitelist:
                whitelisted = True

            if invite.lower() in config.invites_whitelist:
                whitelisted = True

            if need_whitelist and not whitelisted:
                raise Censorship(CensorReason.INVITE, event, ctx={
                    'hit': 'whietlist',
                    'invite': invite,
                    'guild': invite_info,
                    'warn_on_censor': config.warn_on_censor,
                    's': self,
                })
            elif config.invites_blacklist and invite.lower() in config.invites_blacklist:
                raise Censorship(CensorReason.INVITE, event, ctx={
                    'hit': 'blacklist',
                    'invite': invite,
                    'guild': invite_info,
                    'warn_on_censor': config.warn_on_censor,
                    's': self,
                })

    def filter_domains(self, event, config):
        urls = URL_RE.findall(INVITE_LINK_RE.sub('', event.content))

        for url in urls:
            try:
                parsed = urlparse.urlparse(url)
            except:
                continue

            if (config.domains_whitelist or not config.domains_blacklist)\
                    and parsed.netloc.lower() not in config.domains_whitelist:
                raise Censorship(CensorReason.DOMAIN, event, ctx={
                    'hit': 'whitelist',
                    'url': url,
                    'domain': parsed.netloc,
                    'warn_on_censor': config.warn_on_censor,
                    's': self,
                })
            elif config.domains_blacklist and parsed.netloc.lower() in config.domains_blacklist:
                raise Censorship(CensorReason.DOMAIN, event, ctx={
                    'hit': 'blacklist',
                    'url': url,
                    'domain': parsed.netloc,
                    'warn_on_censor': config.warn_on_censor,
                    's': self,
                })

    def filter_blocked_words(self, event, config):
        blocked_words = config.blocked_re.findall(event.content)

        if blocked_words:
            raise Censorship(CensorReason.WORD, event, ctx={
                'words': blocked_words,
                'warn_on_censor': config.warn_on_censor,
                's': self,
            })

    def filter_message_len(self, event, config):
        if config.message_char_limit and config.message_char_limit > 0 and len(event.content) > config.message_char_limit:
            raise Censorship(CensorReason.LENGTH, event, ctx={
                'length': len(event.content),
                'allowed': config.message_char_limit,
                'warn_on_censor': config.warn_on_censor,
                's': self,
            })

    @Plugin.listen('GuildMemberUpdate', priority=Priority.BEFORE)
    def on_guild_member_update(self, event):
        pre_member = event.guild.members.get(event.id)

        if not pre_member:
            return

        if (pre_member.nick or event.nick) and pre_member.nick != event.nick:
            configs = list(self.compute_relevant_configs(event, event))
            if not configs:
                return

            for config in configs:
                if config.blocked_nicknames:
                    self.filter_blocked_nicknames(event, config, pre_member)

                if config.block_zalgo_nicknames:
                    self.filter_zalgo_nicknames(event, config, pre_member)

    @Plugin.listen('PresenceUpdate', priority=Priority.BEFORE)
    def on_guild_member_presence_update(self, event):
        if not event.user:
            return
        pre_member = event.guild.members.get(event.user.id)
        pre_user = self.state.users.get(event.user.id)

        if not pre_user:
            return

        if event.user.username is not UNSET and event.user.username != pre_user.username:
            if event.user.username == pre_member.nick:
                configs = list(self.compute_relevant_configs(event, event))
                if not configs:
                    return

                for config in configs:
                    if config.blocked_nicknames:
                        self.filter_blocked_nicknames(event, config, pre_member)

                    if config.block_zalgo_nicknames:
                        self.filter_zalgo_nicknames(event, config, pre_member)

    @Plugin.listen('GuildMemberAdd')
    def on_guild_member_add(self, event):
        configs = list(self.compute_relevant_configs(event, event))
        if not configs:
            return

        for config in configs:
            if config.blocked_nicknames:
                self.filter_blocked_nicknames(event, config)

            if config.block_zalgo_nicknames:
                self.filter_zalgo_nicknames(event, config)

    def filter_blocked_nicknames(self, event, config, pre_member=None):
        if not event.nick:
            nickname = unicode(event.user)
        else:
            nickname = event.nick
        blocked_nicknames = config.blockednick_re.findall(nickname)

        if blocked_nicknames:
            if not pre_member:
                newnick = 'random name {}'.format(random.randint(1,5000))
                event.set_nickname(newnick)
            else:
                pre_member.set_nickname(pre_member.nick)

            reason='Blacklisted usernames `{}`'.format(
                u', '.join([S(i, escape_codeblocks=True) for i in blocked_nicknames]))
            self.call(
                'ModLogPlugin.log_action_ext',
                Actions.CHANGE_NICK_BLOCKED,
                event.guild.id,
                e=event,
                before=pre_member.nick or '<NO_NICK>',
                after=event.nick or '<NO_NICK>',
                reason=reason
                )
            if config.warn_on_censor:
                Infraction.warn(self, self.state.me, event, reason, guild=event.member.guild)

    def filter_zalgo_nicknames(self, event, config, pre_member=None):
        if not event.nick:
            nickname = unicode(event.user)
        else:
            nickname = event.nick
        zalgo_nicknames = ZALGO_RE.search(nickname)

        if zalgo_nicknames:
            if not pre_member:
                newnick = 'random name {}'.format(random.randint(1,5000))
                event.set_nickname(newnick)
            else:
                pre_member.set_nickname(pre_member.nick)

            reason='Blacklisted usernames, zalgo detected'
            self.call(
                'ModLogPlugin.log_action_ext',
                Actions.CHANGE_NICK_BLOCKED,
                event.guild.id,
                e=event,
                before=pre_member.nick or '<NO_NICK>',
                after=event.nick or '<NO_NICK>',
                reason=reason
                )
            if config.warn_on_censor:
                Infraction.warn(self, self.state.me, event, reason, guild=event.member.guild)
