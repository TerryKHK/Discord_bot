import React, { Component } from 'react';

export default class Tooltip extends Component {
  render() {
    const position = this.props.position || 'right';
    return (
      <div className="tooltipWrap">{this.props.trigger}
        <span className={`tooltiptext ${position}`}>{this.props.text}</span>
      </div>
    );
  }
}
