import React, { Component } from 'react';
import {globalState} from '../state';
import {withRouter} from 'react-router';
import {PREMIUM_ENABLED} from 'config';

export default class GuildStats extends Component {
  render() {
    return (<h1>TEST</h1>);
  }
}
