import React, { Component } from 'react';

class GuildIcon extends Component {
  render() {
    if (this.props.guildIcon) {
      const source = `https://cdn.discordapp.com/icons/${this.props.guildID}/${this.props.guildIcon}.png`;
      return (
            <img src={source} height={this.props.scale || 128} className={this.props.className} alt="No Icon" />
        );
    } else {
      return <i>No Icon</i>;
    }
  }
}

export default GuildIcon;
